# 447-project-webpack

> Police Application : Team 10 final project

## Build Setup


# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# go to http://localhost:8080 to view webapp

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
